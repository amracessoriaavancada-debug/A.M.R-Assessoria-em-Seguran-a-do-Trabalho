// main.js - Funcionalidades gerais do site

// ===== CONTROLE DE CARRINHO =====
class ShoppingCart {
    constructor() {
        this.items = this.loadCart();
        this.updateCartUI();
    }

    // Carregar carrinho do localStorage
    loadCart() {
        const saved = localStorage.getItem('cart');
        return saved ? JSON.parse(saved) : [];
    }

    // Salvar carrinho no localStorage
    saveCart() {
        localStorage.setItem('cart', JSON.stringify(this.items));
    }

    // Adicionar item ao carrinho
    addItem(product) {
        const existing = this.items.find(item => item.id === product.id);
        
        if (existing) {
            existing.quantity += 1;
        } else {
            this.items.push({
                id: product.id,
                name: product.name,
                price: product.price,
                category: product.category,
                downloadUrl: product.downloadUrl || '#',
                quantity: 1
            });
        }
        
        this.saveCart();
        this.updateCartUI();
        this.showNotification('Produto adicionado ao carrinho!', 'success');
    }

    // Remover item do carrinho
    removeItem(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        this.saveCart();
        this.updateCartUI();
    }

    // Atualizar quantidade
    updateQuantity(productId, quantity) {
        const item = this.items.find(item => item.id === productId);
        if (item) {
            item.quantity = Math.max(1, quantity);
            this.saveCart();
            this.updateCartUI();
        }
    }

    // Obter total
    getTotal() {
        return this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    }

    // Obter quantidade total de itens
    getTotalItems() {
        return this.items.reduce((sum, item) => sum + item.quantity, 0);
    }

    // Limpar carrinho
    clear() {
        this.items = [];
        this.saveCart();
        this.updateCartUI();
    }

    // Atualizar UI do carrinho
    updateCartUI() {
        const totalItems = this.getTotalItems();
        
        // Atualizar badges
        const badges = document.querySelectorAll('#cart-badge, #mobile-cart-count');
        badges.forEach(badge => {
            if (totalItems > 0) {
                badge.textContent = totalItems;
                badge.classList.remove('hidden');
            } else {
                badge.classList.add('hidden');
            }
        });

        // Se estamos na página de treinamentos, atualizar modal do carrinho
        if (window.location.pathname.includes('treinamentos.html')) {
            this.renderCartModal();
        }
    }

    // Renderizar modal do carrinho
    renderCartModal() {
        const cartItemsContainer = document.getElementById('cart-items');
        const cartTotal = document.getElementById('cart-total');
        
        if (!cartItemsContainer || !cartTotal) return;

        if (this.items.length === 0) {
            cartItemsContainer.innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-shopping-cart text-gray-300 text-6xl mb-4"></i>
                    <p class="text-gray-600">Seu carrinho está vazio</p>
                </div>
            `;
            cartTotal.textContent = 'R$ 0,00';
            return;
        }

        cartItemsContainer.innerHTML = this.items.map(item => `
            <div class="flex items-start gap-4 pb-4 mb-4 border-b border-gray-200">
                <div class="flex-1">
                    <h4 class="font-semibold text-gray-800 mb-1">${item.name}</h4>
                    <p class="text-sm text-gray-500 mb-2">${item.category}</p>
                    <div class="flex items-center gap-3">
                        <button class="btn-decrease text-gray-500 hover:text-blue-600" data-id="${item.id}">
                            <i class="fas fa-minus"></i>
                        </button>
                        <span class="font-semibold">${item.quantity}</span>
                        <button class="btn-increase text-gray-500 hover:text-blue-600" data-id="${item.id}">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
                <div class="text-right">
                    <p class="font-bold text-blue-600 mb-2">R$ ${(item.price * item.quantity).toFixed(2)}</p>
                    <button class="btn-remove text-red-500 hover:text-red-700 text-sm" data-id="${item.id}">
                        <i class="fas fa-trash"></i> Remover
                    </button>
                </div>
            </div>
        `).join('');

        cartTotal.textContent = `R$ ${this.getTotal().toFixed(2)}`;

        // Adicionar event listeners
        this.attachCartEventListeners();
    }

    // Adicionar event listeners aos botões do carrinho
    attachCartEventListeners() {
        // Remover item
        document.querySelectorAll('.btn-remove').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = e.currentTarget.dataset.id;
                this.removeItem(productId);
            });
        });

        // Diminuir quantidade
        document.querySelectorAll('.btn-decrease').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = e.currentTarget.dataset.id;
                const item = this.items.find(i => i.id === productId);
                if (item && item.quantity > 1) {
                    this.updateQuantity(productId, item.quantity - 1);
                }
            });
        });

        // Aumentar quantidade
        document.querySelectorAll('.btn-increase').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = e.currentTarget.dataset.id;
                const item = this.items.find(i => i.id === productId);
                if (item) {
                    this.updateQuantity(productId, item.quantity + 1);
                }
            });
        });
    }

    // Mostrar notificação
    showNotification(message, type = 'info') {
        // Criar elemento de notificação
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 z-50 px-6 py-4 rounded-lg shadow-lg text-white ${
            type === 'success' ? 'bg-green-600' : 
            type === 'error' ? 'bg-red-600' : 
            'bg-blue-600'
        }`;
        notification.innerHTML = `
            <div class="flex items-center gap-3">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;

        document.body.appendChild(notification);

        // Remover após 3 segundos
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
}

// Instanciar carrinho global
const cart = new ShoppingCart();

// ===== MENU MOBILE =====
document.addEventListener('DOMContentLoaded', () => {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    }

    // Abrir carrinho ao clicar no ícone
    const cartLinks = document.querySelectorAll('a[href="#carrinho"], a[href*="#carrinho"]');
    cartLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const cartModal = document.getElementById('cart-modal');
            if (cartModal) {
                cartModal.classList.remove('hidden');
                cart.renderCartModal();
            }
        });
    });

    // Fechar modal do carrinho
    const closeCartBtn = document.getElementById('close-cart');
    const cartModal = document.getElementById('cart-modal');
    
    if (closeCartBtn && cartModal) {
        closeCartBtn.addEventListener('click', () => {
            cartModal.classList.add('hidden');
        });

        // Fechar ao clicar fora
        cartModal.addEventListener('click', (e) => {
            if (e.target === cartModal) {
                cartModal.classList.add('hidden');
            }
        });
    }
});

// Exportar para uso global
window.cart = cart;