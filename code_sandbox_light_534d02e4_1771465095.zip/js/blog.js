// blog.js - Gerenciamento do blog

document.addEventListener('DOMContentLoaded', async () => {
    // Carregar artigos
    await loadBlogPosts();
    
    // Configurar filtros
    setupBlogFilters();
    
    // Configurar busca
    setupBlogSearch();
});

// ===== CARREGAR ARTIGOS DO BLOG =====
async function loadBlogPosts() {
    try {
        const response = await fetch('tables/blog_posts?limit=100');
        const data = await response.json();
        
        if (data.data && data.data.length > 0) {
            renderBlogPosts(data.data);
        } else {
            // Se não houver artigos, mostrar artigos de exemplo
            showSampleBlogPosts();
        }
    } catch (error) {
        console.error('Erro ao carregar artigos:', error);
        showSampleBlogPosts();
    }
}

// Renderizar artigos do blog
function renderBlogPosts(posts) {
    const container = document.getElementById('blog-container');
    
    if (!container) return;
    
    container.innerHTML = posts.map(post => `
        <article class="bg-white rounded-lg shadow-md overflow-hidden card-hover blog-post" data-category="${post.category}" data-title="${post.title}">
            <div class="relative bg-gradient-to-br ${getCategoryBlogGradient(post.category)} p-12 flex items-center justify-center">
                <i class="${getCategoryBlogIcon(post.category)} text-white text-6xl opacity-50"></i>
            </div>
            <div class="p-6">
                <span class="category-badge ${getCategoryBlogClass(post.category)}">${post.category}</span>
                <h3 class="text-xl font-bold text-gray-800 mt-3 mb-2">${post.title}</h3>
                <p class="text-gray-600 text-sm mb-4 line-clamp-3">${post.excerpt}</p>
                <div class="flex items-center text-xs text-gray-500 mb-4">
                    <i class="fas fa-calendar mr-2"></i>
                    <span>${formatDate(post.date)}</span>
                    <span class="mx-2">•</span>
                    <i class="fas fa-clock mr-2"></i>
                    <span>${post.readTime} min de leitura</span>
                </div>
                <a href="#" class="text-blue-600 font-semibold hover:underline">
                    Ler artigo completo <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </div>
        </article>
    `).join('');
}

// Mostrar artigos de exemplo
function showSampleBlogPosts() {
    const samplePosts = [
        {
            id: 'post-1',
            title: 'Como Implementar um Programa de Prevenção de Acidentes',
            excerpt: 'Descubra as melhores práticas para criar e manter um programa eficaz de prevenção de acidentes na sua empresa, reduzindo riscos e garantindo a segurança dos colaboradores.',
            category: 'Normas NR',
            date: '2026-02-10',
            readTime: 6
        },
        {
            id: 'post-2',
            title: 'Principais EPIs e Quando Utilizá-los',
            excerpt: 'Guia completo sobre os equipamentos de proteção individual mais importantes e suas aplicações específicas em diferentes ambientes de trabalho.',
            category: 'EPI',
            date: '2026-02-08',
            readTime: 5
        },
        {
            id: 'post-3',
            title: 'Mudanças na NR-01: O Que Você Precisa Saber',
            excerpt: 'Entenda as principais alterações na Norma Regulamentadora 01 e como adequar sua empresa às novas exigências legais.',
            category: 'Legislação',
            date: '2026-02-05',
            readTime: 7
        },
        {
            id: 'post-4',
            title: 'Ergonomia no Trabalho: Dicas Práticas',
            excerpt: 'Aprenda a criar um ambiente de trabalho ergonômico que promova a saúde e o bem-estar dos funcionários, prevenindo lesões e aumentando a produtividade.',
            category: 'Saúde Ocupacional',
            date: '2026-02-01',
            readTime: 4
        },
        {
            id: 'post-5',
            title: 'Check-list de Segurança para Construção Civil',
            excerpt: 'Lista completa de verificações essenciais para garantir a segurança em canteiros de obras e evitar acidentes graves.',
            category: 'Normas NR',
            date: '2026-01-28',
            readTime: 8
        },
        {
            id: 'post-6',
            title: 'Como Escolher o Capacete de Segurança Adequado',
            excerpt: 'Conheça os diferentes tipos de capacetes de segurança e saiba qual é o mais adequado para cada tipo de atividade profissional.',
            category: 'EPI',
            date: '2026-01-25',
            readTime: 5
        },
        {
            id: 'post-7',
            title: 'Gestão de Saúde Ocupacional em Pequenas Empresas',
            excerpt: 'Estratégias práticas e acessíveis para pequenas empresas implementarem programas eficazes de saúde ocupacional.',
            category: 'Saúde Ocupacional',
            date: '2026-01-20',
            readTime: 6
        },
        {
            id: 'post-8',
            title: 'Responsabilidades Legais do Empregador em SST',
            excerpt: 'Entenda todas as obrigações legais do empregador em relação à segurança e saúde do trabalho segundo a legislação brasileira.',
            category: 'Legislação',
            date: '2026-01-15',
            readTime: 10
        },
        {
            id: 'post-9',
            title: 'NR-07 e PCMSO: Guia Completo de Implementação',
            excerpt: 'Passo a passo para implementar o Programa de Controle Médico de Saúde Ocupacional na sua empresa de forma eficiente.',
            category: 'Normas NR',
            date: '2026-01-10',
            readTime: 9
        }
    ];
    
    renderBlogPosts(samplePosts);
}

// Obter gradiente por categoria
function getCategoryBlogGradient(category) {
    const gradients = {
        'Normas NR': 'from-blue-500 to-blue-700',
        'EPI': 'from-green-500 to-green-700',
        'Saúde Ocupacional': 'from-orange-500 to-orange-700',
        'Legislação': 'from-purple-500 to-purple-700'
    };
    return gradients[category] || 'from-gray-500 to-gray-700';
}

// Obter ícone por categoria
function getCategoryBlogIcon(category) {
    const icons = {
        'Normas NR': 'fas fa-file-contract',
        'EPI': 'fas fa-hard-hat',
        'Saúde Ocupacional': 'fas fa-heartbeat',
        'Legislação': 'fas fa-balance-scale'
    };
    return icons[category] || 'fas fa-newspaper';
}

// Obter classe CSS por categoria
function getCategoryBlogClass(category) {
    const classes = {
        'Normas NR': 'category-nr',
        'EPI': 'category-epi',
        'Saúde Ocupacional': 'category-saude',
        'Legislação': 'category-legislacao'
    };
    return classes[category] || 'category-nr';
}

// Formatar data
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
        day: '2-digit', 
        month: 'long', 
        year: 'numeric' 
    });
}

// ===== FILTROS =====
function setupBlogFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Remover active de todos
            filterButtons.forEach(b => {
                b.classList.remove('bg-blue-600', 'text-white');
            });
            
            // Adicionar active ao clicado
            e.currentTarget.classList.add('bg-blue-600', 'text-white');
            
            const category = e.currentTarget.dataset.category;
            filterBlogPosts(category);
        });
    });
}

function filterBlogPosts(category) {
    const posts = document.querySelectorAll('.blog-post');
    
    posts.forEach(post => {
        const postCategory = post.dataset.category;
        
        if (category === 'todos' || category === postCategory) {
            post.style.display = 'block';
        } else {
            post.style.display = 'none';
        }
    });
}

// ===== BUSCA =====
function setupBlogSearch() {
    const searchInput = document.getElementById('search-input');
    
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            searchBlogPosts(query);
        });
    }
}

function searchBlogPosts(query) {
    const posts = document.querySelectorAll('.blog-post');
    
    posts.forEach(post => {
        const title = post.dataset.title.toLowerCase();
        
        if (title.includes(query)) {
            post.style.display = 'block';
        } else {
            post.style.display = 'none';
        }
    });
}