// products.js - Gerenciamento de produtos e checkout

document.addEventListener('DOMContentLoaded', async () => {
    // Carregar produtos
    await loadProducts();
    
    // Configurar filtros
    setupFilters();
    
    // Configurar busca
    setupSearch();
    
    // Configurar checkout
    setupCheckout();
});

// ===== CARREGAR PRODUTOS =====
async function loadProducts() {
    try {
        const response = await fetch('tables/products?limit=100');
        const data = await response.json();
        
        if (data.data && data.data.length > 0) {
            renderProducts(data.data);
        } else {
            // Se não houver produtos, mostrar produtos de exemplo
            showSampleProducts();
        }
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
        showSampleProducts();
    }
}

// Renderizar produtos
function renderProducts(products) {
    const container = document.getElementById('products-container');
    
    if (!container) return;
    
    container.innerHTML = products.map(product => `
        <div class="bg-white rounded-lg shadow-md overflow-hidden card-hover product-card" data-category="${product.category}" data-name="${product.name}">
            <div class="relative bg-gradient-to-br ${getCategoryGradient(product.category)} p-8 flex items-center justify-center">
                <i class="${getCategoryIcon(product.category)} text-white text-6xl opacity-80"></i>
                <span class="product-badge">${product.category}</span>
            </div>
            <div class="p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-2">${product.name}</h3>
                <p class="text-gray-600 text-sm mb-4 line-clamp-3">${product.description}</p>
                <div class="flex items-center justify-between mb-4">
                    <div class="text-3xl font-bold text-blue-600">
                        R$ ${parseFloat(product.price).toFixed(2)}
                    </div>
                </div>
                <button 
                    class="btn-add-cart w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
                    data-product='${JSON.stringify(product)}'
                >
                    <i class="fas fa-cart-plus mr-2"></i>
                    Adicionar ao Carrinho
                </button>
            </div>
        </div>
    `).join('');
    
    // Adicionar event listeners
    attachProductEventListeners();
}

// Mostrar produtos de exemplo
function showSampleProducts() {
    const sampleProducts = [
        {
            id: 'prod-1',
            name: 'NR-10 - Segurança em Instalações Elétricas',
            description: 'Documento completo da Norma Regulamentadora 10 com todas as diretrizes para trabalho com eletricidade.',
            price: 49.90,
            category: 'Documento NR',
            downloadUrl: '#'
        },
        {
            id: 'prod-2',
            name: 'Treinamento NR-35 - Trabalho em Altura',
            description: 'Curso completo sobre trabalho em altura com certificado digital válido em todo Brasil.',
            price: 149.90,
            category: 'Treinamento',
            downloadUrl: '#'
        },
        {
            id: 'prod-3',
            name: 'NR-06 - Equipamentos de Proteção Individual',
            description: 'Norma completa sobre EPIs, responsabilidades e procedimentos de uso.',
            price: 39.90,
            category: 'Documento NR',
            downloadUrl: '#'
        },
        {
            id: 'prod-4',
            name: 'Modelo de Laudo PPRA',
            description: 'Template editável de Programa de Prevenção de Riscos Ambientais conforme NR-09.',
            price: 89.90,
            category: 'Laudo',
            downloadUrl: '#'
        },
        {
            id: 'prod-5',
            name: 'Treinamento NR-12 - Segurança em Máquinas',
            description: 'Capacitação sobre operação segura de máquinas e equipamentos industriais.',
            price: 129.90,
            category: 'Treinamento',
            downloadUrl: '#'
        },
        {
            id: 'prod-6',
            name: 'NR-17 - Ergonomia',
            description: 'Norma Regulamentadora sobre adaptação das condições de trabalho ao trabalhador.',
            price: 44.90,
            category: 'Documento NR',
            downloadUrl: '#'
        },
        {
            id: 'prod-7',
            name: 'Modelo de PCMSO Completo',
            description: 'Template de Programa de Controle Médico de Saúde Ocupacional editável.',
            price: 99.90,
            category: 'Laudo',
            downloadUrl: '#'
        },
        {
            id: 'prod-8',
            name: 'Treinamento NR-33 - Espaços Confinados',
            description: 'Curso sobre trabalho seguro em espaços confinados com certificado.',
            price: 169.90,
            category: 'Treinamento',
            downloadUrl: '#'
        },
        {
            id: 'prod-9',
            name: 'NR-05 - CIPA',
            description: 'Documento completo sobre Comissão Interna de Prevenção de Acidentes.',
            price: 34.90,
            category: 'Documento NR',
            downloadUrl: '#'
        }
    ];
    
    renderProducts(sampleProducts);
}

// Obter gradiente por categoria
function getCategoryGradient(category) {
    const gradients = {
        'Documento NR': 'from-blue-500 to-blue-700',
        'Treinamento': 'from-green-500 to-green-700',
        'Laudo': 'from-purple-500 to-purple-700',
        'Consultoria': 'from-orange-500 to-orange-700'
    };
    return gradients[category] || 'from-gray-500 to-gray-700';
}

// Obter ícone por categoria
function getCategoryIcon(category) {
    const icons = {
        'Documento NR': 'fas fa-file-alt',
        'Treinamento': 'fas fa-graduation-cap',
        'Laudo': 'fas fa-clipboard-check',
        'Consultoria': 'fas fa-headset'
    };
    return icons[category] || 'fas fa-file';
}

// Adicionar event listeners aos produtos
function attachProductEventListeners() {
    document.querySelectorAll('.btn-add-cart').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const product = JSON.parse(e.currentTarget.dataset.product);
            window.cart.addItem(product);
        });
    });
}

// ===== FILTROS =====
function setupFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Remover active de todos
            filterButtons.forEach(b => b.classList.remove('active', 'bg-blue-600', 'text-white'));
            
            // Adicionar active ao clicado
            e.currentTarget.classList.add('active', 'bg-blue-600', 'text-white');
            
            const category = e.currentTarget.dataset.category;
            filterProducts(category);
        });
    });
}

function filterProducts(category) {
    const products = document.querySelectorAll('.product-card');
    
    products.forEach(product => {
        const productCategory = product.dataset.category;
        
        if (category === 'todos' || category === productCategory) {
            product.style.display = 'block';
        } else {
            product.style.display = 'none';
        }
    });
}

// ===== BUSCA =====
function setupSearch() {
    const searchInput = document.getElementById('search-input');
    
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            searchProducts(query);
        });
    }
}

function searchProducts(query) {
    const products = document.querySelectorAll('.product-card');
    
    products.forEach(product => {
        const name = product.dataset.name.toLowerCase();
        
        if (name.includes(query)) {
            product.style.display = 'block';
        } else {
            product.style.display = 'none';
        }
    });
}

// ===== CHECKOUT =====
function setupCheckout() {
    const checkoutBtn = document.getElementById('checkout-btn');
    const checkoutModal = document.getElementById('checkout-modal');
    const cancelCheckoutBtn = document.getElementById('cancel-checkout');
    const checkoutForm = document.getElementById('checkout-form');
    const successModal = document.getElementById('success-modal');
    const closeSuccessBtn = document.getElementById('close-success');
    
    // Abrir modal de checkout
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', () => {
            if (window.cart.items.length === 0) {
                window.cart.showNotification('Seu carrinho está vazio!', 'error');
                return;
            }
            
            // Atualizar total no checkout
            const checkoutTotal = document.getElementById('checkout-total');
            if (checkoutTotal) {
                checkoutTotal.textContent = `R$ ${window.cart.getTotal().toFixed(2)}`;
            }
            
            // Fechar modal do carrinho e abrir checkout
            document.getElementById('cart-modal').classList.add('hidden');
            checkoutModal.classList.remove('hidden');
        });
    }
    
    // Cancelar checkout
    if (cancelCheckoutBtn) {
        cancelCheckoutBtn.addEventListener('click', () => {
            checkoutModal.classList.add('hidden');
        });
    }
    
    // Processar pagamento
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Simular processamento
            const submitBtn = checkoutForm.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Processando...';
            
            // Simular delay de processamento
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Preparar lista de downloads
            const downloadList = document.getElementById('download-list');
            downloadList.innerHTML = window.cart.items.map(item => `
                <div class="bg-gray-50 p-4 rounded-lg">
                    <div class="flex justify-between items-center">
                        <div>
                            <p class="font-semibold text-gray-800">${item.name}</p>
                            <p class="text-sm text-gray-500">${item.category}</p>
                        </div>
                        <a 
                            href="${item.downloadUrl}" 
                            download
                            class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm"
                        >
                            <i class="fas fa-download mr-2"></i>
                            Download
                        </a>
                    </div>
                </div>
            `).join('');
            
            // Fechar checkout e abrir sucesso
            checkoutModal.classList.add('hidden');
            successModal.classList.remove('hidden');
            
            // Limpar carrinho
            window.cart.clear();
            
            // Resetar formulário
            checkoutForm.reset();
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-lock mr-2"></i> Confirmar Pagamento';
        });
    }
    
    // Fechar modal de sucesso
    if (closeSuccessBtn) {
        closeSuccessBtn.addEventListener('click', () => {
            successModal.classList.add('hidden');
        });
    }
}