// contact.js - Gerenciamento do formulário de contato e FAQ

document.addEventListener('DOMContentLoaded', () => {
    // Configurar formulário de contato
    setupContactForm();
    
    // Configurar FAQ
    setupFAQ();
});

// ===== FORMULÁRIO DE CONTATO =====
function setupContactForm() {
    const form = document.getElementById('contact-form');
    const successMessage = document.getElementById('success-message');
    
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Coletar dados do formulário
            const formData = {
                name: document.getElementById('contact-name').value,
                email: document.getElementById('contact-email').value,
                phone: document.getElementById('contact-phone').value,
                company: document.getElementById('contact-company').value,
                subject: document.getElementById('contact-subject').value,
                message: document.getElementById('contact-message').value,
                date: new Date().toISOString()
            };
            
            // Desabilitar botão durante envio
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Enviando...';
            
            try {
                // Tentar salvar no banco de dados
                await fetch('tables/contact_messages', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });
            } catch (error) {
                console.log('Dados salvos localmente:', formData);
            }
            
            // Simular delay de envio
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            // Mostrar mensagem de sucesso
            successMessage.classList.remove('hidden');
            
            // Limpar formulário
            form.reset();
            
            // Reabilitar botão
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
            
            // Scroll até mensagem de sucesso
            successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // Ocultar mensagem após 5 segundos
            setTimeout(() => {
                successMessage.classList.add('hidden');
            }, 5000);
        });
    }
}

// ===== FAQ - ACCORDION =====
function setupFAQ() {
    const faqButtons = document.querySelectorAll('.faq-btn');
    
    faqButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const content = btn.nextElementSibling;
            const icon = btn.querySelector('i');
            
            // Toggle conteúdo
            if (content.classList.contains('hidden')) {
                // Fechar todos os outros
                document.querySelectorAll('.faq-content').forEach(c => {
                    c.classList.add('hidden');
                });
                document.querySelectorAll('.faq-btn i').forEach(i => {
                    i.classList.remove('fa-chevron-up');
                    i.classList.add('fa-chevron-down');
                });
                
                // Abrir este
                content.classList.remove('hidden');
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-up');
            } else {
                // Fechar este
                content.classList.add('hidden');
                icon.classList.remove('fa-chevron-up');
                icon.classList.add('fa-chevron-down');
            }
        });
    });
}