# Segurança Brasil - Site de Assessoria em Segurança do Trabalho

## 📋 Sobre o Projeto

Site profissional completo para empresa de assessoria em segurança do trabalho, com foco em democratizar o acesso a documentos de normas brasileiras através de preços acessíveis e entrega rápida para todo o Brasil.

## 🎯 Objetivo Principal

Facilitar o acesso de empresas brasileiras de todos os portes aos documentos e treinamentos essenciais de segurança do trabalho, promovendo conformidade legal e ambientes de trabalho mais seguros.

## ✨ Funcionalidades Implementadas

### 1. **Página Inicial (index.html)**
- ✅ Hero section com apresentação da empresa e proposta de valor
- ✅ Seção "Nossa Missão" com cards explicativos
- ✅ Serviços em destaque (Documentos NR, Treinamentos, Laudos, Consultoria)
- ✅ Números e estatísticas da empresa
- ✅ Depoimentos de clientes
- ✅ Call-to-action para conversão
- ✅ Footer completo com redes sociais e informações de contato

### 2. **Área de Treinamentos/Loja (treinamentos.html)**
- ✅ Catálogo completo de produtos (documentos, treinamentos, laudos)
- ✅ Sistema de busca por nome de produto
- ✅ Filtros por categoria (Todos, Treinamentos, Documentos, Laudos)
- ✅ Cards de produtos com informações detalhadas e preços
- ✅ Botão "Adicionar ao Carrinho" em cada produto
- ✅ Carrinho de compras funcional (modal)
- ✅ Controle de quantidade de produtos no carrinho
- ✅ Cálculo automático de totais
- ✅ Persistência do carrinho usando localStorage
- ✅ Badge indicador de quantidade no ícone do carrinho

### 3. **Sistema de Compra e Checkout**
- ✅ Modal de checkout com formulário completo
- ✅ Campos: Nome, E-mail, CPF/CNPJ, Método de Pagamento
- ✅ Validação de formulário
- ✅ Simulação de processamento de pagamento
- ✅ Feedback visual durante processamento
- ✅ Integração com os métodos: Cartão de Crédito, PIX, Boleto

### 4. **Sistema de Download Pós-Compra**
- ✅ Modal de sucesso após confirmação de pagamento
- ✅ Lista de produtos comprados com botões de download
- ✅ Links de download individuais para cada produto
- ✅ Limpeza automática do carrinho após compra
- ✅ Confirmação visual de compra realizada

### 5. **Blog (blog.html)**
- ✅ Página de blog com artigos sobre segurança do trabalho
- ✅ Artigo em destaque no topo
- ✅ Grid de artigos com imagens, categorias e informações
- ✅ Sistema de busca de artigos
- ✅ Filtros por categoria (Normas NR, EPI, Saúde Ocupacional, Legislação)
- ✅ Badges de categoria com cores diferenciadas
- ✅ Informações de data e tempo de leitura
- ✅ Newsletter para captação de e-mails

### 6. **Página de Contato (contato.html)**
- ✅ Cards informativos com telefone, WhatsApp, e-mail e endereço
- ✅ Formulário completo de contato
- ✅ Campos: Nome, E-mail, Telefone, Empresa, Assunto, Mensagem
- ✅ Validação de campos obrigatórios
- ✅ Feedback de envio com mensagem de sucesso
- ✅ Salvamento de mensagens na tabela do banco de dados
- ✅ Seção de FAQ (Perguntas Frequentes) com accordion
- ✅ CTAs para WhatsApp e telefone

### 7. **Design e Responsividade**
- ✅ Design moderno e profissional usando Tailwind CSS
- ✅ Paleta de cores transmitindo confiança e segurança (azul predominante)
- ✅ Totalmente responsivo (mobile-first)
- ✅ Menu hamburger para dispositivos móveis
- ✅ Animações e transições suaves (hover effects)
- ✅ Ícones do Font Awesome
- ✅ Tipografia Inter (Google Fonts)
- ✅ Cards com efeito hover (elevação)

### 8. **Banco de Dados e API**
- ✅ Tabela `products` para catálogo de produtos
- ✅ Tabela `blog_posts` para artigos do blog
- ✅ Tabela `contact_messages` para mensagens de contato
- ✅ API RESTful integrada para CRUD de dados
- ✅ Dados de exemplo pré-carregados

## 🗂️ Estrutura de Arquivos

```
/
├── index.html                 # Página inicial
├── treinamentos.html          # Loja/catálogo de produtos
├── blog.html                  # Blog de artigos
├── contato.html               # Página de contato
├── js/
│   ├── main.js               # Funcionalidades gerais e carrinho
│   ├── products.js           # Gerenciamento de produtos e checkout
│   ├── blog.js               # Gerenciamento do blog
│   └── contact.js            # Formulário de contato e FAQ
└── README.md                  # Este arquivo
```

## 📊 Estrutura do Banco de Dados

### Tabela: `products`
- `id` (text) - ID único do produto
- `name` (text) - Nome do produto
- `description` (text) - Descrição detalhada
- `price` (number) - Preço em reais
- `category` (text) - Categoria: Documento NR, Treinamento, Laudo, Consultoria
- `downloadUrl` (text) - URL para download
- `featured` (bool) - Se está em destaque
- `active` (bool) - Se está ativo

### Tabela: `blog_posts`
- `id` (text) - ID único do post
- `title` (text) - Título do artigo
- `excerpt` (text) - Resumo
- `content` (rich_text) - Conteúdo completo
- `category` (text) - Categoria: Normas NR, EPI, Saúde Ocupacional, Legislação
- `date` (datetime) - Data de publicação
- `readTime` (number) - Tempo de leitura em minutos
- `author` (text) - Nome do autor
- `featured` (bool) - Se está em destaque
- `published` (bool) - Se está publicado

### Tabela: `contact_messages`
- `id` (text) - ID único da mensagem
- `name` (text) - Nome do contato
- `email` (text) - E-mail
- `phone` (text) - Telefone
- `company` (text) - Nome da empresa
- `subject` (text) - Assunto
- `message` (text) - Mensagem
- `date` (datetime) - Data do contato
- `status` (text) - Status: Novo, Em andamento, Respondido, Fechado

## 🚀 URIs e Funcionalidades Principais

### Páginas Públicas
- **/** ou **/index.html** - Página inicial com apresentação da empresa
- **/treinamentos.html** - Catálogo de produtos e sistema de compra
- **/blog.html** - Blog com artigos sobre segurança do trabalho
- **/contato.html** - Formulário de contato e FAQ

### Funcionalidades JavaScript
- **Carrinho de Compras** - Adicionar/remover produtos, controlar quantidade
- **Checkout** - Formulário de pagamento e processamento
- **Downloads** - Sistema de download pós-compra
- **Filtros** - Busca e filtragem de produtos e artigos
- **Validação** - Validação de formulários
- **LocalStorage** - Persistência do carrinho entre sessões

### API RESTful (Endpoints Disponíveis)
- `GET /tables/products` - Lista todos os produtos
- `GET /tables/blog_posts` - Lista todos os artigos
- `POST /tables/contact_messages` - Envia mensagem de contato
- `GET /tables/{table}/{id}` - Busca registro específico
- `PUT /tables/{table}/{id}` - Atualiza registro
- `DELETE /tables/{table}/{id}` - Remove registro

## 📦 Produtos Cadastrados (Exemplos)

1. **NR-10 - Segurança em Instalações Elétricas** - R$ 49,90
2. **Treinamento NR-35 - Trabalho em Altura** - R$ 149,90
3. **NR-06 - Equipamentos de Proteção Individual** - R$ 39,90
4. **Modelo de Laudo PPRA** - R$ 89,90
5. **Treinamento NR-12 - Segurança em Máquinas** - R$ 129,90
6. **NR-17 - Ergonomia** - R$ 44,90
7. **Modelo de PCMSO Completo** - R$ 99,90
8. **Treinamento NR-33 - Espaços Confinados** - R$ 169,90
9. **NR-05 - CIPA** - R$ 34,90

## 🔧 Tecnologias Utilizadas

- **HTML5** - Estrutura semântica
- **CSS3** - Estilização customizada
- **Tailwind CSS** - Framework CSS utility-first
- **JavaScript (ES6+)** - Interatividade e lógica
- **Font Awesome 6** - Ícones
- **Google Fonts (Inter)** - Tipografia
- **LocalStorage API** - Persistência de dados do carrinho
- **Fetch API** - Comunicação com banco de dados

## 🎨 Paleta de Cores

- **Azul Principal**: #3b82f6 (Confiança e Segurança)
- **Azul Escuro**: #1e3a8a (Header e elementos importantes)
- **Verde**: #10b981 (Sucesso e CTAs secundários)
- **Vermelho**: #ef4444 (Alertas e badges)
- **Cinza**: #6b7280 (Textos secundários)
- **Branco**: #ffffff (Backgrounds e textos)

## 📱 Recursos Responsivos

- ✅ Breakpoints otimizados (mobile, tablet, desktop)
- ✅ Menu hamburguer para dispositivos móveis
- ✅ Grid responsivo com Tailwind CSS
- ✅ Imagens e cards adaptáveis
- ✅ Formulários otimizados para touch
- ✅ Modais responsivos

## 🔐 Funcionalidades de Segurança

- ✅ Validação de formulários no frontend
- ✅ Sanitização básica de inputs
- ✅ Feedback visual de erros
- ✅ Proteção contra submissão duplicada

## 📈 Próximos Passos Recomendados

### Funcionalidades Ainda Não Implementadas

1. **Sistema de Autenticação**
   - Login/registro de usuários
   - Área do cliente
   - Histórico de compras

2. **Integração de Pagamento Real**
   - Gateway de pagamento (Mercado Pago, PagSeguro, Stripe)
   - Webhooks para confirmação automática
   - Geração de boletos e PIX real

3. **Painel Administrativo**
   - Dashboard de vendas
   - Gerenciamento de produtos
   - Gerenciamento de blog
   - Visualização de mensagens de contato

4. **Sistema de E-mail**
   - E-mail de confirmação de compra
   - E-mail com links de download
   - Newsletter automática
   - Resposta automática de contato

5. **Recursos Avançados**
   - Sistema de cupons de desconto
   - Programa de afiliados
   - Chat ao vivo
   - Sistema de reviews/avaliações
   - Comparação de produtos
   - Lista de desejos

6. **SEO e Marketing**
   - Meta tags otimizadas
   - Schema.org markup
   - Sitemap XML
   - Google Analytics
   - Facebook Pixel
   - Blog posts completos com conteúdo rico

7. **Segurança**
   - HTTPS obrigatório
   - Rate limiting
   - CAPTCHA em formulários
   - Backup automático de dados

## 🤝 Como Adicionar Produtos

Para adicionar novos produtos ao catálogo:

```javascript
// Use a API RESTful
await fetch('tables/products', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
        id: 'prod-10',
        name: 'Nome do Produto',
        description: 'Descrição detalhada',
        price: 99.90,
        category: 'Treinamento',
        downloadUrl: '#download-link',
        featured: false,
        active: true
    })
});
```

## 📝 Como Adicionar Artigos no Blog

```javascript
// Use a API RESTful
await fetch('tables/blog_posts', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
        id: 'post-6',
        title: 'Título do Artigo',
        excerpt: 'Resumo curto',
        content: 'Conteúdo completo...',
        category: 'Normas NR',
        date: new Date().toISOString(),
        readTime: 5,
        author: 'Seu Nome',
        featured: false,
        published: true
    })
});
```

## 🌐 Deploy

Para publicar o site:

1. Acesse a aba **Publish** no painel
2. Clique em **Publish Project**
3. Aguarde a geração da URL pública
4. Compartilhe o link com seus clientes

## 📞 Informações de Contato (Configuradas no Site)

- **E-mail**: contato@segurancabrasil.com.br
- **Telefone**: (11) 3456-7890
- **WhatsApp**: (11) 98765-4321
- **Endereço**: São Paulo, SP - Brasil

## 🎓 Público-Alvo

- Empresas de pequeno porte
- Empresas de médio porte
- Grandes corporações
- Profissionais de segurança do trabalho
- Engenheiros de segurança
- Técnicos de segurança
- Gestores de RH

## 💼 Modelo de Negócio

- **B2B** - Venda para empresas
- **B2C** - Venda para profissionais autônomos
- **Produtos Digitais** - Download imediato após compra
- **Assinaturas** (futuro) - Acesso recorrente a conteúdos

## 📊 Métricas de Sucesso

- Taxa de conversão de visitantes em compradores
- Ticket médio por compra
- Produtos mais vendidos
- Artigos mais lidos
- Mensagens de contato recebidas
- Taxa de retorno de clientes

## 🏆 Diferenciais Competitivos

✅ **Preços Acessíveis** - Democratização do acesso
✅ **Entrega Imediata** - Download instantâneo
✅ **Conformidade Total** - Documentos atualizados
✅ **Atendimento Nacional** - Todo o Brasil
✅ **Qualidade Garantida** - Materiais profissionais
✅ **Suporte Especializado** - Equipe técnica qualificada

---

**Desenvolvido com ❤️ para democratizar a segurança do trabalho no Brasil**

*Versão: 1.0.0*  
*Data: Fevereiro de 2026*